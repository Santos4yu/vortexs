let captured = [];

const status = document.getElementById("status");
const count = document.getElementById("count");
const result = document.getElementById("result");
const send = document.getElementById("send");
const target = document.getElementById("target");

chrome.storage.local.get(["targetUrl"], (saved) => {
  if (saved.targetUrl) target.value = saved.targetUrl;
});

target.addEventListener("change", () => chrome.storage.local.set({ targetUrl: target.value.trim() }));

document.getElementById("scan").addEventListener("click", async () => {
  status.textContent = "Reading the visible PrizePicks CS2 cards…";
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url?.includes("prizepicks.com")) {
    status.textContent = "Open PrizePicks in this tab first.";
    return;
  }
  const [{ result: rows = [] }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: captureCs2Props });
  captured = rows;
  result.hidden = false;
  count.textContent = `${rows.length} CS2 props found`;
  status.textContent = rows.length ? "Board captured. Open it in Prop Lab to confirm every row." : "No CS2 cards found. Select CS2 and scroll through the whole board first.";
  send.disabled = rows.length === 0;
});

send.addEventListener("click", () => {
  const base = target.value.trim().replace(/\/$/, "");
  const payload = btoa(unescape(encodeURIComponent(JSON.stringify(captured))));
  chrome.storage.local.set({ targetUrl: base }, () => chrome.tabs.create({ url: `${base}/?board=${encodeURIComponent(payload)}` }));
});

function captureCs2Props() {
  const MARKET = /(maps?\s*1\s*[-–]\s*2\s*(?:kills?|headshots?))/i;
  const LINE = /(?:^|\s)(\d{1,2}(?:\.5)?)(?=\s|$)/g;
  const textOf = (node) => (node.innerText || "").replace(/\s+/g, " ").trim();
  const candidates = [...document.querySelectorAll("article,[role='button'],[class*='projection'],[class*='card'],li")]
    .filter((node) => MARKET.test(textOf(node)) && textOf(node).length < 500);
  const smallest = candidates.filter((node) => ![...node.children].some((child) => MARKET.test(textOf(child)) && textOf(child).length < textOf(node).length * 0.88));
  const seen = new Set();
  const rows = [];

  for (const node of smallest) {
    const raw = textOf(node);
    const marketMatch = raw.match(MARKET);
    if (!marketMatch) continue;
    const beforeMarket = raw.slice(0, marketMatch.index ?? 0).trim();
    const afterMarket = raw.slice((marketMatch.index ?? 0) + marketMatch[0].length);
    const numbers = [...raw.matchAll(LINE)].map((match) => Number(match[1])).filter((number) => number >= 5 && number <= 60);
    const line = numbers.at(-1);
    if (!line) continue;
    const versus = raw.match(/(?:vs\.?|versus)\s+([A-Za-z0-9 ._-]{2,30})/i)?.[1]?.trim() ?? "";
    const fragments = beforeMarket.split(/\s{2,}|\n/).map((part) => part.trim()).filter(Boolean);
    const player = fragments.at(-1)?.replace(/\b(More|Less|Demon|Goblin)\b/gi, "").trim() ?? "";
    if (!player || player.length > 40) continue;
    const market = /headshot/i.test(marketMatch[0]) ? "maps_1_2_headshots" : "maps_1_2_kills";
    const key = `${player.toLowerCase()}|${market}|${line}`;
    if (seen.has(key)) continue;
    seen.add(key);
    rows.push({ player, team: "", opponent: versus, market, line, startTime: afterMarket.match(/(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)[^0-9]*\d{1,2}:\d{2}\s*(?:AM|PM)/i)?.[0] ?? "", source: "PrizePicks", capturedText: raw });
  }
  return rows;
}
